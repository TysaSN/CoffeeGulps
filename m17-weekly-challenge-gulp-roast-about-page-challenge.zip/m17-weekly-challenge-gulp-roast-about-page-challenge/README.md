# M17 Weekly Challenge: Gulp Roast About Page Challenge

A Pen created on CodePen.io. Original URL: [https://codepen.io/Tysasngo/pen/OJoVpyB](https://codepen.io/Tysasngo/pen/OJoVpyB).

